package sim.util.opt;

import ec.*;
import ec.util.*;
import sim.engine.*;
import java.lang.reflect.*;
import sim.util.*;

public class Optimize extends Master
	{
	public Optimize(SimState simstate, ParameterDatabase base)
		{
		super(simstate, base);
		}
		
	public boolean start()	
		{
		Properties properties = MASONProblem.getProperties(simstate);
		base.set(new ec.util.Parameter("eval.problem"), "sim.util.opt.MASONProblem");

		// set up genome
		int numIndexes = base.getInt(new ec.util.Parameter("num-mason-properties"), null);
		base.set(new ec.util.Parameter("pop.subpop.0.species.genome-size"), "" + numIndexes);
		int[] indexes = new int[numIndexes];
		Object[] throwaway = new Object[0];
		
		for(int i = 0; i < numIndexes; i++)
			{
			String name = base.getString(new ec.util.Parameter("mason-property." + i), null);
			indexes[i] = properties.indexForName(name);
			System.err.println("Property " + name + " is " + indexes[i]);
			Object domain = properties.getDomain(indexes[i]);
			Class type = properties.getType(indexes[i]);
			double _min = 0.0;
			double _max = 1.0;
			if (type == Boolean.TYPE)
				{
				if (domain != null)
					System.err.println("ERROR: boolean property " + name + " has a domain: " + domain);
				else
					{
					// do nothing, we're set up
					}
				}
			else if (type == Integer.TYPE)
				{
				if (domain == null || !(throwaway.getClass().isAssignableFrom(domain.getClass())))
					System.err.println("ERROR: integer property " + name + " has a domain: " + domain);
				else
					{
					_min = 0;
					_max = ((Object[])domain).length - 1;
					}
				}
			else if (type == Double.TYPE)
				{
				if (domain == null || !(domain instanceof sim.util.Interval))
					System.err.println("ERROR: double property " + name + " has a domain: " + domain);
				else
					{
					sim.util.Interval interval = (sim.util.Interval)domain;
					_min = interval.getMin().doubleValue();
					_max = interval.getMax().doubleValue();
					}
				}
			else
				{
				System.err.println("ERROR: property " + name + " has is of invalid type: " + type);
				}
			base.set(new ec.util.Parameter("pop.subpop.0.species.min-gene." + i), "" + _min);
			base.set(new ec.util.Parameter("pop.subpop.0.species.max-gene." + i), "" + _max);
			}
		
		
		// Other Model parameters
		int numObjectives = base.getInt(new ec.util.Parameter("mason-objectives"), null);
		if (numObjectives == -1)
			{
			numObjectives = 1;
			}
		base.set(new ec.util.Parameter("multi.fitness.num-objectives"), "" + numObjectives);
			
		int maximumSteps = base.getInt(new ec.util.Parameter("mason-steps"), null);
		int numTrials = base.getInt(new ec.util.Parameter("mason-num-trials"), null);
		boolean rebuildSimState = base.getBoolean(new ec.util.Parameter("rebuild-model"), null, false);
		
		// Build an EvolutionState on it
		super.start();
		

		// After startFresh we have loaded from the parameter database and we're ready to go.
		// But we have not yet called sendAdditionalData on the MasterProblem.  So we set up
		// the MASONProblem to prepare it for that eventuality.  Now we build the MASONProblem.
		
		MASONProblem problem = (MASONProblem)(evolutionState.evaluator.masterproblem.problem);
		problem.modelClassName = simstate.getClass().getName();
		
		problem.loadDefaults(simstate, indexes, numObjectives, maximumSteps, numTrials, rebuildSimState);

		return true; // always for now FIXME
		}
		
	public static void main(String[] args)
		{
		ParameterDatabase base = Evolve.loadParameterDatabase(new String[] { "-from", args[0], "-at", "sim.util.opt.Optimize" });

		new Optimize(buildSimState(sim.app.geo.refugee.Migration.class), base).run();
		}
	}
